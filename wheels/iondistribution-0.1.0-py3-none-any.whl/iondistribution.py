import math
from dataclasses import dataclass, field
from types import SimpleNamespace

import matplotlib.pyplot as plt

import numpy as np

import sys

def is_notebook():
    try:
        from IPython import get_ipython
        return "IPKernelApp" in get_ipython().config
    except Exception:
        return False


class ProgressPrinter:
    def __init__(self):
        self.in_notebook = is_notebook()
        if self.in_notebook:
            from IPython.display import display
            self.handle = display("", display_id=True)
        else:
            self._last_len = 0

    def update(self, text):
        if self.in_notebook:
            self.handle.update(text)
        else:
            # overwrite only the current line
            pad = max(0, self._last_len - len(text))
            sys.stdout.write("\r" + text + " " * pad)
            sys.stdout.flush()
            self._last_len = len(text)

    def done(self):
        if not self.in_notebook:
            print()



@dataclass
class IonSpecies:
    sigma: float  # Angstrom
    epsilon_kj_mol: float
    charge: int


@dataclass
class SimulationConfig:
    surface_distance: float = 200.0  # Angstrom
    box_area: float = 10000.0        # Angstrom^2
    n_anion: int = 20
    n_cation: int = 20
    charge_dens_left: float = -20.0
    charge_dens_right: float = 0.0
    temperature: float = 298.0
    initialize_random: bool = True
    delta: float = 5.0
    nmc: int = 10000
    grres: float = 0.5
    seed: int | None = None


class IonDistributionMC:
    """
    Jupyter-friendly Python rewrite of the MATLAB iondistribution code.

    Usage in a notebook:
        sim = IonDistributionMC(seed=123)
        sim.print_system_info()
        sim.initialize()
        sim.run_segment(production=False)
        sim.plot_energy()
        sim.run_segment(production=True)
        sim.plot_profiles()
        sim.plot_gr()
        sim.print_free_energy()
    """

    def __init__(self, config: SimulationConfig | None = None, *, seed: int | None = None):
        self.cfg = config or SimulationConfig(seed=seed)
        if seed is not None:
            self.cfg.seed = seed
        self.rng = np.random.default_rng(self.cfg.seed)

        # Physical constants
        self.e = 1.6022e-19
        self.kB = 1.3807e-23
        self.e0 = 8.8542e-12
        self.NA = 6.0221e23
        self.T = self.cfg.temperature

        # Ion library
        self.IONLIB = {
            "Li": IonSpecies(2.37, 0.149, 1),
            "Na": IonSpecies(2.73, 0.358, 1),
            "K": IonSpecies(3.36, 1.120, 1),
            "Rb": IonSpecies(3.57, 1.602, 1),
            "Cs": IonSpecies(3.92, 2.132, 1),
            "F": IonSpecies(4.00, 0.050, -1),
            "Cl": IonSpecies(4.86, 0.168, -1),
            "Br": IonSpecies(5.04, 0.270, -1),
            "I": IonSpecies(5.40, 0.408, -1),
        }

        # Default system: Cl-/Na+
        self.anion = self.IONLIB["Cl"]
        self.cation = self.IONLIB["Na"]

        # Geometry
        self.S = SimpleNamespace()
        self.S.SurfaceDistance = self.cfg.surface_distance
        self.S.BoxArea = self.cfg.box_area
        self.S.BoxL = math.sqrt(self.S.BoxArea)
        self.S.BoxV = self.S.BoxArea * self.S.SurfaceDistance
        self.S.chargeDensLeft = self.cfg.charge_dens_left
        self.S.chargeDensRight = self.cfg.charge_dens_right
        self.S.er = 306.7 * math.exp(-self.T / 218.6)

        # Ions
        self.IONS = SimpleNamespace()
        self.IONS.chAnIon = self.anion.charge
        self.IONS.chCatIon = self.cation.charge
        self.IONS.nAnIon = self.cfg.n_anion
        self.IONS.nCatIon = self.cfg.n_cation
        self.IONS.LJAnIon = np.array([self.anion.sigma, self.anion.epsilon_kj_mol], dtype=float)
        self.IONS.LJCatIon = np.array([self.cation.sigma, self.cation.epsilon_kj_mol], dtype=float)

        # Output containers
        self.GR = SimpleNamespace()
        self.GR.grres = self.cfg.grres
        self.GR.r = np.arange(0.5, self.S.BoxL / 2 + self.cfg.grres * 0.5, self.cfg.grres)
        self.GR.grAll = np.zeros_like(self.GR.r)
        self.GR.grAnAn = np.zeros_like(self.GR.r)
        self.GR.grAnCat = np.zeros_like(self.GR.r)
        self.GR.ngr = 0
        self.GR.rhoAll = (self.IONS.nAnIon + self.IONS.nCatIon) / self.S.BoxV
        self.GR.rhoAn = self.IONS.nAnIon / self.S.BoxV
        self.GR.rhoCat = self.IONS.nCatIon / self.S.BoxV

        self.BOXP = SimpleNamespace()
        self.BOXP.xres = self.S.SurfaceDistance / 100
        self.BOXP.x = np.arange(0, self.S.SurfaceDistance + self.BOXP.xres * 0.5, self.BOXP.xres)
        self.BOXP.pAll = np.zeros_like(self.BOXP.x)
        self.BOXP.pAn = np.zeros_like(self.BOXP.x)
        self.BOXP.pCat = np.zeros_like(self.BOXP.x)
        self.BOXP.n = 0

        # Conversion factors
        self.efac = self.e**2 / (4 * math.pi * self.e0 * self.S.er * 1e-10)
        self.efacMol = self.efac * self.NA / (self.IONS.nAnIon + self.IONS.nCatIon)
        self.boltzfac = self.efac / (self.kB * self.T)
        self.cconv = 1 / (1e-30 * self.NA)

        self.IONS.cAll = (self.IONS.nAnIon + self.IONS.nCatIon) * self.cconv / self.S.BoxV
        self.IONS.cAn = self.IONS.nAnIon * self.cconv / self.S.BoxV
        self.IONS.cCat = self.IONS.nCatIon * self.cconv / self.S.BoxV
        self.IONS.I = 0.5 * (self.IONS.cAn * self.IONS.chAnIon**2 + self.IONS.cCat * self.IONS.chCatIon**2)
        self.IONS.LD = math.sqrt(self.S.er * self.e0 * 8.3145 * self.T / (2 * 96485**2 * self.IONS.I)) / 1e-10

        # Dielectric scaling of LJ epsilon
        self.IONS.LJAnIon[1] /= self.S.er
        self.IONS.LJCatIon[1] /= self.S.er

        self.pbcoord = np.array([1, 2]) if (self.S.chargeDensLeft != 0 or self.S.chargeDensRight != 0) else np.array([0, 1, 2])

        self.E = None
        self.Elong = np.zeros(self.cfg.nmc)
        self.EfullRun: list[float] = []
        self.EprodRun: list[float] = []
        self.initialized = False
        self.plotpoints = None

    def print_system_info(self):
        print("---------------------------")
        print("Welcome to iondistribution2!")
        print("(c) Kristofer Modig, 2015.")
        print("    Updated with LJ 2020.")
        print("    Python rewrite for Jupyter.")
        print("---------------------------")
        print("Some data for your system:")
        print("  Concentrations:")
        print(f"    Total ion concentration is {self.IONS.cAll:.6g} mM")
        print(f"    An-ion concentration is {self.IONS.cAn:.6g} mM")
        print(f"    Cat-ion concentration is {self.IONS.cCat:.6g} mM")
        print(f"    Ionic strength is {self.IONS.I:.6g} mM")
        print(f"    Debye length is {self.IONS.LD:.6g} A")
        print("  Simulation box:")
        print(f"    Distance between planes is {self.S.SurfaceDistance:.6g} A")
        print(f"    Box area along plane is {self.S.BoxArea:.6g} A^2")
        print(f"    Box side is {self.S.BoxL:.6g} A")
        print(f"    Box volume is {self.S.BoxV:.6g} A^3")
        print("  Lennard Jones Parameters (energy reduced by rel perm):")
        print(f"    {'i-j':>8s}  {'sig (A)':>8s}  {'eps (J/mol)':>11s}")
        print(f"    {'an-an':>8s}  {self.IONS.LJAnIon[0]:8.3f}  {self.IONS.LJAnIon[1] * 1000:11.3f}")
        print(f"    {'cat-cat':>8s}  {self.IONS.LJCatIon[0]:8.3f}  {self.IONS.LJCatIon[1] * 1000:11.3f}")
        print(
            f"    {'an-cat':>8s}  {(self.IONS.LJCatIon[0] + self.IONS.LJAnIon[0]) / 2:8.3f}"
            f"  {math.sqrt(self.IONS.LJCatIon[1] * self.IONS.LJAnIon[1]) * 1000:11.3f}"
        )
        if len(self.pbcoord) == 3:
            print("No charged boundary. Periodic boundary in all directions.")
        else:
            print("Charged boundary. Periodic boundary y and z directions.")

    def initialize(self, show=False):
        n_total = self.IONS.nAnIon + self.IONS.nCatIon

        if self.cfg.initialize_random:
            pos = self.rng.random((n_total, 3))
            pos[:, 0] *= self.S.SurfaceDistance
            pos[:, 1] *= self.S.BoxL
            pos[:, 2] *= self.S.BoxL
        else:
            pos = np.zeros((n_total, 3), dtype=float)
            pos[:, 0] = np.linspace(3, self.S.SurfaceDistance - 3, n_total)
            pos[:, 1] = np.linspace(3, self.S.BoxL - 3, n_total)
            pos[:, 2] = np.linspace(self.S.BoxL - 3, 3, n_total)
        self.IONS.Pos = pos

        charge = np.zeros(n_total, dtype=float)
        charge[: self.IONS.nAnIon] = self.IONS.chAnIon
        charge[self.IONS.nAnIon :] = self.IONS.chCatIon
        self.IONS.Charge = charge

        # Convert epsilon from kJ/mol to reduced simulation units
        self.IONS.LJAnIon[1] = (self.IONS.LJAnIon[1] * 1000 / self.NA) / self.efac
        self.IONS.LJCatIon[1] = (self.IONS.LJCatIon[1] * 1000 / self.NA) / self.efac

        lj = np.zeros((n_total, 2), dtype=float)
        lj[: self.IONS.nAnIon, 0] = self.IONS.LJAnIon[0]
        lj[: self.IONS.nAnIon, 1] = self.IONS.LJAnIon[1]
        lj[self.IONS.nAnIon :, 0] = self.IONS.LJCatIon[0]
        lj[self.IONS.nAnIon :, 1] = self.IONS.LJCatIon[1]
        self.IONS.LJ = lj

        energy = 0.0
        for i in range(len(self.IONS.Charge)):
            energy += self.mcenergy(i)[0]
        self.E = energy / 2

        self.initialized = True
        if show:
            plt.ion()
            self.plotfig, ax = plt.subplots()
            self.plotpoints=ax.scatter(self.IONS.Pos[:,0],self.IONS.Pos[:,1],c=self.IONS.Charge,cmap='bwr')
            plt.show()

        return self.E

    def _apply_periodic_to_all_positions(self):
        pbcomp = np.array([self.S.SurfaceDistance, self.S.BoxL, self.S.BoxL], dtype=float)
        for dim in self.pbcoord:
            self.IONS.Pos[:, dim] = np.mod(self.IONS.Pos[:, dim], pbcomp[dim])

    def mcenergy(self, i: int):
        ipos = np.tile(self.IONS.Pos[i], (len(self.IONS.Charge), 1))
        rvec = self.IONS.Pos - ipos

        pbcomp = np.tile(np.array([self.S.SurfaceDistance, self.S.BoxL, self.S.BoxL], dtype=float), (len(self.IONS.Charge), 1))
        for dim in self.pbcoord:
            over = rvec[:, dim] > pbcomp[:, dim] / 2
            rvec[over, dim] -= pbcomp[over, dim]
            under = rvec[:, dim] < -pbcomp[:, dim] / 2
            rvec[under, dim] += pbcomp[under, dim]

        dist = np.sqrt(np.sum(rvec**2, axis=1))
        with np.errstate(divide='ignore', invalid='ignore'):
            E2 = self.IONS.Charge[i] * self.IONS.Charge / dist

        sigLJ = 0.5 * (self.IONS.LJ[i, 0] + self.IONS.LJ[:, 0])
        lj_mask = (dist < 3 * sigLJ) & (np.arange(len(dist)) != i)
        if np.any(lj_mask):
            eLJ = np.sqrt(self.IONS.LJ[i, 1] * self.IONS.LJ[lj_mask, 1])
            sig_rrat6 = (sigLJ[lj_mask] / dist[lj_mask]) ** 6
            E2[lj_mask] = E2[lj_mask] + 4 * eLJ * (sig_rrat6**2 - sig_rrat6)

        E = np.sum(E2[np.arange(len(self.IONS.Charge)) != i])
        EwallL = 0.0
        EwallR = 0.0

        if self.S.chargeDensLeft != 0 or self.S.chargeDensRight != 0:
            rad2 = self.S.BoxArea / math.pi
            prefL = 4 * math.pi * self.S.chargeDensLeft / self.S.BoxArea / 2
            prefR = 4 * math.pi * self.S.chargeDensRight / self.S.BoxArea / 2
            x = self.IONS.Pos[i, 0]
            potL = prefL * (math.sqrt(rad2 + x**2) - x)
            potR = prefR * (math.sqrt(rad2 + (self.S.SurfaceDistance - x) ** 2) - (self.S.SurfaceDistance - x))
            EwallL = potL * self.IONS.Charge[i]
            EwallR = potR * self.IONS.Charge[i]
            E += EwallL + EwallR

        return E, E2, EwallL, EwallR

    def gofr(self, R: np.ndarray):
        delg = R[1] - R[0]
        grAll = np.zeros_like(R)
        grAnCat = np.zeros_like(R)
        grAnAn = np.zeros_like(R)

        ixAn = np.where(self.IONS.Charge < 0)[0]
        ixCat = np.where(self.IONS.Charge > 0)[0]
        n_total = len(self.IONS.Charge)
        pbcomp = np.tile(np.array([self.S.SurfaceDistance, self.S.BoxL, self.S.BoxL], dtype=float), (n_total, 1))

        for i in range(n_total):
            ipos = np.tile(self.IONS.Pos[i], (n_total, 1))
            rvec = self.IONS.Pos - ipos

            for dim in self.pbcoord:
                over = rvec[:, dim] > pbcomp[:, dim] / 2
                rvec[over, dim] -= pbcomp[over, dim]
                under = rvec[:, dim] < -pbcomp[:, dim] / 2
                rvec[under, dim] += pbcomp[under, dim]

            rtmp = np.sqrt(np.sum(rvec**2, axis=1))

            if i + 1 < n_total:
                bins_all = np.floor(rtmp[i + 1 :] / delg).astype(int)
                bins_all = bins_all[(bins_all >= 1) & (bins_all <= len(grAll))]
                np.add.at(grAll, bins_all - 1, 2)

            if np.sign(self.IONS.Charge[i]) < 0:
                same_ix = ixAn[ixAn > i]
                bins_same = np.floor(rtmp[same_ix] / delg).astype(int)
                bins_same = bins_same[(bins_same >= 1) & (bins_same <= len(grAll))]
                np.add.at(grAnAn, bins_same - 1, 2)

                opp_ix = ixCat[ixCat > i]
                bins_opp = np.floor(rtmp[opp_ix] / delg).astype(int)
                bins_opp = bins_opp[(bins_opp >= 1) & (bins_opp <= len(grAll))]
                np.add.at(grAnCat, bins_opp - 1, 1)

        return grAll, grAnCat, grAnAn

    def sample_observables(self):
        grAll, grAnCat, grAnAn = self.gofr(self.GR.r)
        self.GR.grAll += grAll
        self.GR.grAnCat += grAnCat
        self.GR.grAnAn += grAnAn
        self.GR.ngr += 1

        counts_all, _ = np.histogram(self.IONS.Pos[:, 0], bins=len(self.BOXP.x)-1, range=(0, self.S.SurfaceDistance))
        an_mask = self.IONS.Charge < 0
        cat_mask = self.IONS.Charge > 0
        counts_an, _ = np.histogram(self.IONS.Pos[an_mask, 0], bins=len(self.BOXP.x)-1, range=(0, self.S.SurfaceDistance))
        counts_cat, _ = np.histogram(self.IONS.Pos[cat_mask, 0], bins=len(self.BOXP.x)-1, range=(0, self.S.SurfaceDistance))

        self.BOXP.pAll += counts_all
        self.BOXP.pAn += counts_an
        self.BOXP.pCat += counts_cat
        self.BOXP.n += 1

    def run_segment(self, nmc: int | None = None, *, production: bool = False, sample_every: int = 10, adapt_every: int = 1000, plot_every: int = 1000,verbose: bool = True):
        if not self.initialized:
            raise RuntimeError("Call initialize() before run_segment().")

        nmc = nmc or self.cfg.nmc
        usedSteps = np.zeros(adapt_every, dtype=int)
        Elong = np.zeros(nmc, dtype=float)
        print(f"Running {nmc} steps of " + ("production" if production else "equilibration..."))
        print(self.plotpoints)
        pp = ProgressPrinter()
        for step in range(nmc):
            ix = self.rng.integers(0, self.IONS.nAnIon + self.IONS.nCatIon)
            tmppos = self.IONS.Pos[ix].copy()
            Eixold = self.mcenergy(ix)[0]

            self.IONS.Pos[ix] = self.IONS.Pos[ix] + self.cfg.delta * (self.rng.random(3) - 0.5)

            usestep = True
            if self.IONS.Pos[ix, 0] >= self.S.SurfaceDistance or self.IONS.Pos[ix, 0] <= 0:
                usestep = False

            if usestep:
                self._apply_periodic_to_all_positions()
                Eixnew = self.mcenergy(ix)[0]
                if Eixnew > Eixold:
                    p = math.exp(-(Eixnew - Eixold) * self.boltzfac)
                    if self.rng.random() > p:
                        usestep = False
            else:
                Eixnew = Eixold

            if usestep:
                usedSteps[step % adapt_every] = 1
                self.E = self.E - Eixold + Eixnew
            else:
                self.IONS.Pos[ix] = tmppos

            Elong[step] = self.E

            if (step + 1) % adapt_every == 0:
                pAccept = usedSteps.mean()
                if pAccept > 0:
                    self.cfg.delta = self.cfg.delta * pAccept / 0.75
                if verbose:
                    pp.update(f"Step {step+1} of {nmc}. Accepted {pAccept * 100:.2f}% of the moves. delta changed to {self.cfg.delta:.4f} A")
                usedSteps[:] = 0

            if production and ((step + 1) % sample_every == 0):
                self.sample_observables()

            if self.plotpoints != None and (step + 1) % plot_every == 0:
                self.plotpoints.set_offsets(np.c_[self.IONS.Pos[:,0],self.IONS.Pos[:,1]])
                self.plotfig.canvas.draw()
                self.plotfig.canvas.flush_events()

        pp.update("Simulation done.")
        pp.done()
        self.Elong = Elong
        self.EfullRun.extend(Elong.tolist())
        if production:
            self.EprodRun.extend(Elong.tolist())
        return Elong

    def normalized_profiles(self):
        if self.BOXP.n == 0:
            raise RuntimeError("No production samples collected yet.")
        vb = self.BOXP.xres * self.S.BoxArea
        cAllNorm = self.BOXP.pAll / self.BOXP.n * self.cconv / vb
        cAnNorm = self.BOXP.pAn / self.BOXP.n * self.cconv / vb
        cCatNorm = self.BOXP.pCat / self.BOXP.n * self.cconv / vb
        return cAllNorm, cCatNorm, cAnNorm

    def normalized_gr(self):
        if self.GR.ngr == 0:
            raise RuntimeError("No g(r) samples collected yet.")
        vb = 4 * math.pi / 3 * (self.GR.r**3 - (self.GR.r - self.GR.grres) ** 3)
        grAllnorm = self.GR.grAll / (vb * self.GR.ngr * self.GR.rhoAll * (self.IONS.nAnIon + self.IONS.nCatIon))
        grAnCatnorm = self.GR.grAnCat / (vb * self.GR.ngr * self.GR.rhoCat * self.IONS.nAnIon)
        grAnAnnorm = self.GR.grAnAn / (vb * self.GR.ngr * self.GR.rhoAn * self.IONS.nAnIon)
        return grAllnorm, grAnCatnorm, grAnAnnorm

    def plot_energy(self):
        plt.figure(figsize=(8, 4.5))
        plt.plot(np.array(self.EfullRun) * self.efacMol)
        plt.xlabel("Simulation step")
        plt.ylabel("Energy (J/mol)")
        if self.EprodRun:
            mean_kj = np.mean(self.EprodRun) * self.efacMol / 1000
            mean_rt = np.mean(self.EprodRun) * self.efacMol / (8.3145 * self.T)
            plt.title(f"<Delta F>_el = {mean_kj:.4g} kJ/mol and <Delta F>_el/RT = {mean_rt:.4g} (per ion)")
        plt.tight_layout()
        plt.show()

    def plot_profiles(self):
        cAllNorm, cCatNorm, cAnNorm = self.normalized_profiles()
        plt.figure(figsize=(8, 4.5))
        plt.plot(self.BOXP.x, cAllNorm, label="All ions")
        plt.plot(self.BOXP.x, cCatNorm, label="Cation")
        plt.plot(self.BOXP.x, cAnNorm, label="Anion")
        plt.xlabel("x (Angstrom)")
        plt.ylabel("Concentration (mM)")
        plt.title(f"Concentrations from {self.BOXP.n} snapshots")
        plt.legend()
        plt.tight_layout()
        plt.show()

    def plot_gr(self):
        grAllnorm, grAnCatnorm, grAnAnnorm = self.normalized_gr()
        plt.figure(figsize=(8, 4.5))
        plt.plot(self.GR.r, grAllnorm, label="All ions")
        plt.plot(self.GR.r, grAnCatnorm, label="Anion-Cation")
        plt.plot(self.GR.r, grAnAnnorm, label="Anion-Anion")
        plt.xlabel("r (Angstrom)")
        plt.ylabel("g(r)")
        plt.title(f"g(r) from {self.GR.ngr} snapshots")
        plt.legend()
        plt.tight_layout()
        plt.show()

    def print_free_energy(self):
        if not self.EprodRun:
            raise RuntimeError("No production run available yet.")
        mean_per_ion_kj = np.mean(self.EprodRun) * self.efacMol / 1000
        mean_per_ion_rt = np.mean(self.EprodRun) * self.efacMol / (8.3145 * self.T)
        n_total = self.IONS.nAnIon + self.IONS.nCatIon
        print(f"Electrostatic free energy after {len(self.EprodRun)} steps:")
        print("  Per ion:")
        print(f"    <Delta F> = {mean_per_ion_kj:.4g} kJ/mol")
        print(f"    <Delta F>/(RT) = {mean_per_ion_rt:.4g}")
        print(f"  For all {self.IONS.nAnIon}+{self.IONS.nCatIon} = {n_total} ions:")
        print(f"    <Delta F> = {mean_per_ion_kj * n_total:.4g} kJ/mol")
        print(f"    <Delta F>/(RT) = {mean_per_ion_rt * n_total:.4g}")


# Example notebook usage:
# from iondistribution import IonDistributionMC, SimulationConfig
# cfg = SimulationConfig(nmc=10000, initialize_random=False, seed=123)
# sim = IonDistributionMC(cfg)
# sim.print_system_info()
# sim.initialize()
# sim.run_segment(production=False)
# sim.plot_energy()
# sim.run_segment(production=True)
# sim.plot_energy()
# sim.plot_profiles()
# sim.plot_gr()
# sim.print_free_energy()

